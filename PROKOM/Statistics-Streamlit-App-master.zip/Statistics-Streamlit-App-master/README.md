# Analysis-Streamlit-App

I developed this app since many of my friends needed to perform an experiment on their dataset and there was no easy way to do so online. The majority of management and marketing students must conduct their statistical experiments using Stata or SPSS, which does not appear to be a straightforward thing. This [link](https://stormy-taiga-49001.herokuapp.com/) is the application I deployed on Heroku. Happy statisitics!

# Features

## Linear Regression

Linear regression is a method of modelling the connection between a scalar response and one or more explanatory factors in statistics.

## ANOVA

Analysis of variance (ANOVA) is a collection of statistical models and estimate processes for analysing variations between means.
